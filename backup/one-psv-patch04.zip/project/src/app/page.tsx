"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import ColorImageOverlay from "../components/ColorImageOverlay";
import { DotsIcon } from "../components/icons";

// ── Types ─────────────────────────────────────────────────────
type Folder = { id: string; name: string; createdAt: number };
type Memo = {
  id: string;
  folderId: string | null;
  date: string;
  text: string;
  createdAt: number;
  color?: string | null;
  image?: string | null;
  note?: string | null;
};
type AppState = {
  version: 1;
  folders: Folder[];
  memos: Memo[];
  activeFolder: string;
};

// Drag state — global ref (no re-render needed)
type DropTarget = { date: string; beforeId: string | null } | null;

// ── Storage ───────────────────────────────────────────────────
const STORAGE_KEY = "one_psv_v1";
function loadState(): AppState {
  if (typeof window === "undefined") return seed();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return seed();
    const d = JSON.parse(raw);
    if (d?.version !== 1) return seed();
    return d as AppState;
  } catch { return seed(); }
}
function seed(): AppState {
  return { version: 1, folders: [], memos: [], activeFolder: "all" };
}
let _saveTimer: ReturnType<typeof setTimeout> | null = null;
function debouncedSave(state: AppState) {
  if (_saveTimer) clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
  }, 300);
}

// ── Constants ─────────────────────────────────────────────────
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
const PALETTE = [
  "#FFEA00", "#00E5FF", "#FF3D00", "#00E676", "#B388FF",
  "#FF80AB", "#FFD180", "#69F0AE", "#82B1FF", "#FFFFFF",
];
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function monthKey(d: string) { return d.slice(0, 7); }
function dayNum(d: string)   { return parseInt(d.slice(8, 10), 10); }
function fmtMonth(ym: string) {
  const [y, m] = ym.split("-");
  return `${y}년 ${parseInt(m, 10)}월`;
}

// ── NotePanel ─────────────────────────────────────────────────
function NotePanel({ memo, onSave, onClose }: {
  memo: Memo; onSave: (id: string, note: string) => void; onClose: () => void;
}) {
  const [val, setVal] = useState(memo.note ?? "");
  const taRef = useRef<HTMLTextAreaElement>(null);
  const commitRef = useRef<() => void>(() => {});
  commitRef.current = () => onSave(memo.id, val);
  useEffect(() => { taRef.current?.focus(); }, []);
  useEffect(() => () => { commitRef.current(); }, []);

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", background: "#15151b" }}>
      <div style={{ height: 44, minHeight: 44, display: "flex", alignItems: "center", padding: "0 14px 0 16px", borderBottom: "1px solid rgba(255,255,255,0.07)", gap: 8 }}>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0, color: "rgba(255,255,255,0.22)" }}>
          <path d="M4 6h16M4 10h10M4 14h7M4 18h5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.28)", fontFamily: "'JetBrains Mono',monospace", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {memo.text}
        </span>
        <button onClick={onClose}
          style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.22)", fontSize: 18, lineHeight: 1, padding: "2px 4px" }}
          onMouseEnter={e => (e.currentTarget.style.color = "rgba(255,255,255,0.6)")}
          onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.22)")}
        >×</button>
      </div>
      <textarea ref={taRef} value={val}
        onChange={e => setVal(e.target.value)}
        onBlur={() => onSave(memo.id, val)}
        placeholder="노트를 입력하세요…"
        style={{ flex: 1, background: "transparent", border: "none", outline: "none", resize: "none", padding: "16px 18px", color: "rgba(255,255,255,0.72)", fontSize: 13, lineHeight: 1.8, fontFamily: "'Noto Sans KR',sans-serif" }}
      />
    </div>
  );
}

// ── Pill ──────────────────────────────────────────────────────
function Pill({
  memo, openMenu, isDragging,
  onUpdate, onOpenMenu, onCloseMenu,
  onPickColor, onPickImage, onClearImage, onOpenNote, onDelete,
  onDragStart, onDragEnd,
}: {
  memo: Memo; openMenu: boolean; isDragging: boolean;
  onUpdate: (id: string, text: string) => void;
  onOpenMenu: (id: string) => void; onCloseMenu: () => void;
  onPickColor: (id: string, color: string | null) => void;
  onPickImage: (id: string, dataUrl: string) => void;
  onClearImage: (id: string) => void;
  onOpenNote: (id: string) => void;
  onDelete: (id: string) => void;
  onDragStart: (id: string) => void;
  onDragEnd: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const spanRef = useRef<HTMLSpanElement>(null);
  const origRef = useRef(memo.text);

  const startEdit = (e: React.MouseEvent) => {
    if (openMenu) return;
    e.stopPropagation();
    origRef.current = memo.text;
    setEditing(true);
    setTimeout(() => {
      const el = spanRef.current;
      if (!el) return;
      el.focus();
      const range = document.createRange();
      range.selectNodeContents(el);
      window.getSelection()?.removeAllRanges();
      window.getSelection()?.addRange(range);
    }, 0);
  };

  const finish = () => {
    setEditing(false);
    const newText = spanRef.current?.textContent?.trim() ?? "";
    if (newText && newText !== origRef.current) onUpdate(memo.id, newText);
    else if (spanRef.current) spanRef.current.textContent = origRef.current;
  };

  const hasNote = !!(memo.note && memo.note.trim());
  const color = memo.color ?? null;
  const borderColor = editing ? "var(--accent)" : color ? `${color}66` : "var(--border2)";
  const bgColor = color ? `${color}12` : editing ? "rgba(184,255,106,0.07)" : "var(--surface2)";

  return (
    <div
      className="pill-wrap"
      draggable={!editing}
      onDragStart={e => {
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", memo.id);
        onDragStart(memo.id);
      }}
      onDragEnd={onDragEnd}
      onDoubleClick={startEdit}
      onMouseEnter={e => {
        if (editing || openMenu) return;
        e.currentTarget.style.borderColor = "rgba(255,255,255,0.24)";
        const btn = e.currentTarget.querySelector<HTMLElement>(".pill-dots");
        if (btn) btn.style.opacity = "1";
      }}
      onMouseLeave={e => {
        if (editing || openMenu) return;
        e.currentTarget.style.borderColor = borderColor;
        const btn = e.currentTarget.querySelector<HTMLElement>(".pill-dots");
        if (btn) btn.style.opacity = "0";
      }}
      style={{
        display: "inline-flex", alignItems: "center", gap: 5,
        padding: "5px 8px", borderRadius: 999,
        border: `1px solid ${borderColor}`,
        background: bgColor,
        fontSize: 13, color: "var(--text)",
        whiteSpace: "nowrap", flexShrink: 0,
        transition: "border-color 0.15s, background 0.15s, opacity 0.15s",
        userSelect: editing ? "text" : "none",
        cursor: isDragging ? "grabbing" : "grab",
        opacity: isDragging ? 0.35 : 1,
      }}
    >
      {hasNote && (
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: color ?? "var(--accent)", flexShrink: 0, display: "inline-block" }} />
      )}
      <span ref={spanRef} contentEditable={editing} suppressContentEditableWarning
        onBlur={finish}
        onKeyDown={e => {
          if (e.key === "Enter") { e.preventDefault(); spanRef.current?.blur(); }
          if (e.key === "Escape") { if (spanRef.current) spanRef.current.textContent = origRef.current; setEditing(false); }
          e.stopPropagation();
        }}
        style={{ outline: "none" }}
      >{memo.text}</span>
      <button className="pill-dots"
        onClick={e => { e.stopPropagation(); onOpenMenu(memo.id); }}
        style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.35)", padding: "0 1px", lineHeight: 1, opacity: openMenu ? 1 : 0, transition: "opacity 0.15s, color 0.15s", flexShrink: 0, display: "flex", alignItems: "center" }}
        onMouseEnter={e => (e.currentTarget.style.color = "rgba(255,255,255,0.85)")}
        onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.35)")}
      >
        <DotsIcon size={14} />
      </button>
      <ColorImageOverlay
        open={openMenu} currentColor={color} palette={PALETTE} hasImage={!!memo.image}
        onPickColor={c => onPickColor(memo.id, c)}
        onPickImage={async (dataUrl) => onPickImage(memo.id, dataUrl)}
        onClearImage={() => onClearImage(memo.id)}
        onOpenNote={() => onOpenNote(memo.id)}
        onDelete={() => onDelete(memo.id)}
        onClose={onCloseMenu}
      />
    </div>
  );
}

// ── DropCursor — 드롭 위치 표시 | ────────────────────────────
function DropCursor() {
  return (
    <div style={{
      display: "inline-flex", alignItems: "center",
      width: 2, minWidth: 2, alignSelf: "stretch",
      flexShrink: 0, position: "relative",
    }}>
      <div style={{
        position: "absolute", top: -2, bottom: -2, left: 0,
        width: 2, borderRadius: 2,
        background: "var(--accent)",
        boxShadow: "0 0 6px var(--accent)",
      }} />
    </div>
  );
}

// ── DayRow ────────────────────────────────────────────────────
function DayRow({
  dateStr, memos, openMenuId, draggingId, dropTarget,
  onUpdate, onOpenMenu, onCloseMenu,
  onPickColor, onPickImage, onClearImage, onOpenNote, onDelete, onClickEmpty,
  onDragStart, onDragEnd, onDragOverSlot, onDropSlot,
}: {
  dateStr: string; memos: Memo[]; openMenuId: string | null;
  draggingId: string | null; dropTarget: DropTarget;
  onUpdate: (id: string, text: string) => void;
  onOpenMenu: (id: string) => void; onCloseMenu: () => void;
  onPickColor: (id: string, color: string | null) => void;
  onPickImage: (id: string, dataUrl: string) => void;
  onClearImage: (id: string) => void;
  onOpenNote: (id: string) => void;
  onDelete: (id: string) => void;
  onClickEmpty: (d: string) => void;
  onDragStart: (id: string) => void;
  onDragEnd: () => void;
  // date, beforeId(null=맨뒤)
  onDragOverSlot: (date: string, beforeId: string | null) => void;
  onDropSlot: (date: string, beforeId: string | null) => void;
}) {
  const today = dateStr === todayStr();
  const sorted = [...memos].sort((a, b) => a.createdAt - b.createdAt);

  // 슬롯 진입/드롭 핸들러
  const makeSlotHandlers = (beforeId: string | null) => ({
    onDragOver: (e: React.DragEvent) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      onDragOverSlot(dateStr, beforeId);
    },
    onDrop: (e: React.DragEvent) => {
      e.preventDefault();
      onDropSlot(dateStr, beforeId);
    },
  });

  // 현재 행이 드롭 타겟인지
  const isTarget = (beforeId: string | null) =>
    !!draggingId && dropTarget?.date === dateStr && dropTarget?.beforeId === beforeId;

  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
      {/* 날짜 숫자 — 드롭존 포함 */}
      <div
        {...makeSlotHandlers(sorted[0]?.id ?? null)}
        style={{
          fontFamily: "'JetBrains Mono',monospace", fontSize: 11,
          color: today ? "var(--accent)" : "var(--text3)",
          fontWeight: today ? 500 : 400,
          minWidth: 28, paddingTop: 8, flexShrink: 0, textAlign: "right",
        }}
      >
        {String(dayNum(dateStr)).padStart(2, "0")}
      </div>

      {/* pill 영역 */}
      <div
        onClick={e => { if (e.target === e.currentTarget) onClickEmpty(dateStr); }}
        onDragOver={e => { e.preventDefault(); onDragOverSlot(dateStr, null); }}
        onDrop={e => { e.preventDefault(); onDropSlot(dateStr, null); }}
        style={{
          flex: 1, display: "flex", flexWrap: "nowrap", gap: 0,
          overflowX: "auto", padding: "3px 0 6px",
          scrollbarWidth: "none", alignItems: "center",
          minHeight: 36, cursor: "default",
        }}
      >
        {/* 맨 앞 드롭 슬롯 */}
        <DropSlot show={isTarget(sorted[0]?.id ?? null)} handlers={makeSlotHandlers(sorted[0]?.id ?? null)} />

        {sorted.map((m, i) => (
          <React.Fragment key={m.id}>
            <div style={{ padding: "0 3.5px" }}>
              <Pill
                memo={m}
                openMenu={openMenuId === m.id}
                isDragging={draggingId === m.id}
                onUpdate={onUpdate}
                onOpenMenu={onOpenMenu} onCloseMenu={onCloseMenu}
                onPickColor={onPickColor} onPickImage={onPickImage} onClearImage={onClearImage}
                onOpenNote={onOpenNote} onDelete={onDelete}
                onDragStart={onDragStart} onDragEnd={onDragEnd}
              />
            </div>
            {/* pill 뒤 슬롯 */}
            <DropSlot
              show={isTarget(sorted[i + 1]?.id ?? null)}
              handlers={makeSlotHandlers(sorted[i + 1]?.id ?? null)}
            />
          </React.Fragment>
        ))}

        {memos.length === 0 && (
          <span onClick={() => onClickEmpty(dateStr)}
            style={{ fontSize: 12, color: "var(--text3)", paddingTop: 7, cursor: "text", userSelect: "none", paddingLeft: 4 }}
          >—</span>
        )}
      </div>
    </div>
  );
}

// ── DropSlot — 투명 히트 영역 + 커서 ─────────────────────────
function DropSlot({ show, handlers }: {
  show: boolean;
  handlers: { onDragOver: (e: React.DragEvent) => void; onDrop: (e: React.DragEvent) => void };
}) {
  return (
    <div
      {...handlers}
      style={{
        display: "inline-flex", alignItems: "stretch",
        width: show ? 10 : 8, minWidth: show ? 10 : 8,
        alignSelf: "stretch", flexShrink: 0,
        position: "relative", transition: "width 0.1s",
      }}
    >
      {show && <DropCursor />}
    </div>
  );
}

// ── MonthPanel ────────────────────────────────────────────────
function MonthPanel({
  mk, byDay, openMenuId, draggingId, dropTarget,
  onUpdate, onOpenMenu, onCloseMenu,
  onPickColor, onPickImage, onClearImage, onOpenNote, onDelete, onClickEmpty,
  onDragStart, onDragEnd, onDragOverSlot, onDropSlot,
}: {
  mk: string; byDay: Record<string, Memo[]>; openMenuId: string | null;
  draggingId: string | null; dropTarget: DropTarget;
  onUpdate: (id: string, text: string) => void;
  onOpenMenu: (id: string) => void; onCloseMenu: () => void;
  onPickColor: (id: string, color: string | null) => void;
  onPickImage: (id: string, dataUrl: string) => void;
  onClearImage: (id: string) => void;
  onOpenNote: (id: string) => void;
  onDelete: (id: string) => void;
  onClickEmpty: (d: string) => void;
  onDragStart: (id: string) => void;
  onDragEnd: () => void;
  onDragOverSlot: (date: string, beforeId: string | null) => void;
  onDropSlot: (date: string, beforeId: string | null) => void;
}) {
  const days = Object.keys(byDay).sort().reverse();
  const total = days.reduce((s, d) => s + byDay[d].length, 0);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }} data-month={mk}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "var(--text3)", letterSpacing: "0.07em" }}>
          {fmtMonth(mk)}
        </span>
        <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: "var(--text3)" }}>{total}</span>
      </div>
      {days.map(d => (
        <DayRow
          key={d} dateStr={d} memos={byDay[d]} openMenuId={openMenuId}
          draggingId={draggingId} dropTarget={dropTarget}
          onUpdate={onUpdate} onOpenMenu={onOpenMenu} onCloseMenu={onCloseMenu}
          onPickColor={onPickColor} onPickImage={onPickImage} onClearImage={onClearImage}
          onOpenNote={onOpenNote} onDelete={onDelete} onClickEmpty={onClickEmpty}
          onDragStart={onDragStart} onDragEnd={onDragEnd}
          onDragOverSlot={onDragOverSlot} onDropSlot={onDropSlot}
        />
      ))}
    </div>
  );
}

// ── FolderModal ───────────────────────────────────────────────
function FolderModal({ onConfirm, onCancel }: { onConfirm: (n: string) => void; onCancel: () => void }) {
  const [val, setVal] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { ref.current?.focus(); }, []);
  return (
    <div onClick={e => { if (e.target === e.currentTarget) onCancel(); }}
      style={{ position: "fixed", inset: 0, zIndex: 999, background: "rgba(0,0,0,0.65)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()}
        style={{ background: "var(--surface)", border: "1px solid var(--border2)", borderRadius: 14, padding: "22px 22px 18px", minWidth: 280, boxShadow: "0 20px 60px rgba(0,0,0,0.6)" }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: "var(--text)", marginBottom: 14 }}>새 폴더</div>
        <input ref={ref} value={val} onChange={e => setVal(e.target.value)} placeholder="폴더 이름" maxLength={40}
          onKeyDown={e => { if (e.key === "Enter" && val.trim()) onConfirm(val.trim()); if (e.key === "Escape") onCancel(); }}
          style={{ width: "100%", padding: "9px 12px", background: "var(--surface2)", border: "1px solid var(--border2)", borderRadius: 8, color: "var(--text)", fontSize: 13, outline: "none", fontFamily: "'Noto Sans KR',sans-serif" }}
          onFocus={e => (e.target.style.borderColor = "var(--accent)")}
          onBlur={e => (e.target.style.borderColor = "var(--border2)")} />
        <div style={{ display: "flex", gap: 8, marginTop: 14, justifyContent: "flex-end" }}>
          <button onClick={onCancel} style={{ padding: "7px 14px", borderRadius: 7, border: "1px solid var(--border2)", background: "none", color: "var(--text2)", cursor: "pointer", fontSize: 12, fontFamily: "'Noto Sans KR',sans-serif" }}>취소</button>
          <button onClick={() => val.trim() && onConfirm(val.trim())} disabled={!val.trim()}
            style={{ padding: "7px 14px", borderRadius: 7, border: "none", background: val.trim() ? "var(--accent)" : "var(--surface2)", color: val.trim() ? "#111" : "var(--text3)", cursor: val.trim() ? "pointer" : "default", fontSize: 12, fontWeight: 600, fontFamily: "'Noto Sans KR',sans-serif" }}>만들기</button>
        </div>
      </div>
    </div>
  );
}

// ── DeleteFolderModal ─────────────────────────────────────────
function DeleteFolderModal({ name, onConfirm, onCancel }: { name: string; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div onClick={e => { if (e.target === e.currentTarget) onCancel(); }}
      style={{ position: "fixed", inset: 0, zIndex: 999, background: "rgba(0,0,0,0.65)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()}
        style={{ background: "var(--surface)", border: "1px solid var(--border2)", borderRadius: 14, padding: "22px 22px 18px", minWidth: 280, boxShadow: "0 20px 60px rgba(0,0,0,0.6)" }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: "var(--text)", marginBottom: 8 }}>폴더 삭제</div>
        <div style={{ fontSize: 13, color: "var(--text2)", marginBottom: 20 }}>
          <span style={{ color: "var(--text)", fontWeight: 500 }}>"{name}"</span> 폴더를 삭제할까요?<br />
          <span style={{ fontSize: 12, color: "var(--text3)" }}>메모는 All로 이동됩니다.</span>
        </div>
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <button onClick={onCancel} style={{ padding: "7px 14px", borderRadius: 7, border: "1px solid var(--border2)", background: "none", color: "var(--text2)", cursor: "pointer", fontSize: 12, fontFamily: "'Noto Sans KR',sans-serif" }}>취소</button>
          <button onClick={onConfirm} style={{ padding: "7px 14px", borderRadius: 7, border: "none", background: "#ff5252", color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, fontFamily: "'Noto Sans KR',sans-serif" }}>삭제</button>
        </div>
      </div>
    </div>
  );
}

// ── FolderItem ────────────────────────────────────────────────
function FolderItem({ folder, isActive, memoCount, onSelect, onDelete, onRename }: {
  folder: Folder; isActive: boolean; memoCount: number;
  onSelect: () => void; onDelete: () => void; onRename: (n: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(folder.name);
  const ref = useRef<HTMLInputElement>(null);
  const commit = () => {
    setEditing(false);
    if (val.trim() && val.trim() !== folder.name) onRename(val.trim());
    else setVal(folder.name);
  };
  if (editing) return (
    <input ref={ref} value={val} onChange={e => setVal(e.target.value)} onBlur={commit} autoFocus
      onKeyDown={e => { if (e.key === "Enter") commit(); if (e.key === "Escape") { setVal(folder.name); setEditing(false); } }}
      style={{ width: "100%", padding: "7px 10px", margin: "1px 0", background: "rgba(255,255,255,0.07)", border: "1px solid var(--border2)", borderRadius: 7, color: "var(--text)", fontSize: 14, outline: "none", fontFamily: "'Noto Sans KR',sans-serif" }} />
  );
  return (
    <div style={{ position: "relative", display: "flex", alignItems: "center" }}
      onMouseEnter={e => { const b = e.currentTarget.querySelector<HTMLElement>(".fdel"); if (b) b.style.opacity = "1"; }}
      onMouseLeave={e => { const b = e.currentTarget.querySelector<HTMLElement>(".fdel"); if (b) b.style.opacity = "0"; }}>
      <button onClick={onSelect} onDoubleClick={e => { e.stopPropagation(); setEditing(true); }}
        style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", paddingRight: 28, borderRadius: 8, border: "none", background: isActive ? "rgba(255,255,255,0.09)" : "none", color: isActive ? "var(--text)" : "var(--text2)", cursor: "pointer", fontSize: 14, fontWeight: isActive ? 600 : 400, textAlign: "left", width: "100%", fontFamily: "'Noto Sans KR',sans-serif", transition: "background 0.15s" }}
        onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "rgba(255,255,255,0.05)"; }}
        onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "none"; }}>
        <span style={{ fontSize: 16, color: isActive ? "rgba(255,255,255,0.35)" : "rgba(255,255,255,0.16)", lineHeight: 1, flexShrink: 0 }}>·</span>
        <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{folder.name}</span>
        {memoCount > 0 && <span style={{ fontSize: 11, color: "var(--text3)", flexShrink: 0 }}>{memoCount}</span>}
      </button>
      <button className="fdel" onClick={e => { e.stopPropagation(); onDelete(); }}
        style={{ position: "absolute", right: 6, background: "none", border: "none", cursor: "pointer", color: "var(--text3)", fontSize: 13, padding: "2px 4px", borderRadius: 4, opacity: 0, transition: "opacity 0.15s" }}
        onMouseEnter={e => (e.currentTarget.style.color = "#ff6b6b")}
        onMouseLeave={e => (e.currentTarget.style.color = "var(--text3)")}
      >✕</button>
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────
export default function Page() {
  const [state, setState]           = useState<AppState>(() => seed());
  const [hydrated, setHydrated]     = useState(false);
  const [dateVal, setDateVal]       = useState(todayStr());
  const [inputText, setInputText]   = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Folder | null>(null);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [noteMemoId, setNoteMemoId] = useState<string | null>(null);

  // Drag state
  const [draggingId, setDraggingId]   = useState<string | null>(null);
  const [dropTarget, setDropTarget]   = useState<DropTarget>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setState(loadState()); setHydrated(true); }, []);

  const update = useCallback((updater: (s: AppState) => AppState) => {
    setState(prev => { const next = updater(prev); debouncedSave(next); return next; });
  }, []);

  // ── Memo actions ──────────────────────────────────────────
  const addMemo = () => {
    const text = inputText.trim();
    if (!text || !dateVal) return;
    const folderId = state.activeFolder === "all" ? null : state.activeFolder;
    const memo: Memo = { id: uid(), folderId, date: dateVal, text, createdAt: Date.now() };
    update(s => ({ ...s, memos: [...s.memos, memo] }));
    setInputText("");
    setTimeout(() => {
      document.querySelector(`[data-month="${monthKey(dateVal)}"]`)
        ?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }, 80);
  };

  const updateMemo = (id: string, text: string) =>
    update(s => ({ ...s, memos: s.memos.map(m => m.id === id ? { ...m, text } : m) }));

  const deleteMemo = (id: string) => {
    update(s => ({ ...s, memos: s.memos.filter(m => m.id !== id) }));
    if (noteMemoId === id) setNoteMemoId(null);
    setOpenMenuId(null);
  };

  const pickColor   = (id: string, color: string | null) =>
    update(s => ({ ...s, memos: s.memos.map(m => m.id === id ? { ...m, color } : m) }));
  const pickImage   = async (id: string, dataUrl: string) =>
    update(s => ({ ...s, memos: s.memos.map(m => m.id === id ? { ...m, image: dataUrl } : m) }));
  const clearImage  = (id: string) =>
    update(s => ({ ...s, memos: s.memos.map(m => m.id === id ? { ...m, image: null } : m) }));
  const saveNote    = (id: string, note: string) =>
    update(s => ({ ...s, memos: s.memos.map(m => m.id === id ? { ...m, note } : m) }));

  // ── Drag & Drop ───────────────────────────────────────────
  const handleDragStart = useCallback((id: string) => {
    setDraggingId(id);
    setDropTarget(null);
  }, []);

  const handleDragEnd = useCallback(() => {
    setDraggingId(null);
    setDropTarget(null);
  }, []);

  const handleDragOverSlot = useCallback((date: string, beforeId: string | null) => {
    setDropTarget(prev => {
      if (prev?.date === date && prev?.beforeId === beforeId) return prev;
      return { date, beforeId };
    });
  }, []);

  const handleDropSlot = useCallback((date: string, beforeId: string | null) => {
    const dragId = draggingId;
    setDraggingId(null);
    setDropTarget(null);
    if (!dragId) return;

    update(s => {
      const memo = s.memos.find(m => m.id === dragId);
      if (!memo) return s;

      // 같은 위치면 no-op
      const sameDayMemos = s.memos
        .filter(m => m.date === date && m.id !== dragId)
        .sort((a, b) => a.createdAt - b.createdAt);

      const beforeIndex = beforeId ? sameDayMemos.findIndex(m => m.id === beforeId) : sameDayMemos.length;
      const currentDayMemos = s.memos
        .filter(m => m.date === memo.date && m.id !== dragId)
        .sort((a, b) => a.createdAt - b.createdAt);
      const currentIndex = currentDayMemos.findIndex(m => m.id === (beforeId ?? "__last__"));

      // 날짜 변경 또는 위치 변경 — createdAt을 재계산해서 순서 적용
      const targetMemos = sameDayMemos;
      const insertAt = beforeId ? targetMemos.findIndex(m => m.id === beforeId) : targetMemos.length;

      // 새 createdAt 값 계산
      const now = Date.now();
      const before = insertAt > 0 ? targetMemos[insertAt - 1].createdAt : now - 100000;
      const after  = insertAt < targetMemos.length ? targetMemos[insertAt].createdAt : now + 100000;
      const newCreatedAt = Math.round((before + after) / 2);

      return {
        ...s,
        memos: s.memos.map(m =>
          m.id === dragId
            ? { ...m, date, createdAt: newCreatedAt }
            : m
        ),
      };
    });
  }, [draggingId, update]);

  // ── Folder actions ─────────────────────────────────────────
  const createFolder = (name: string) => {
    const f: Folder = { id: uid(), name, createdAt: Date.now() };
    update(s => ({ ...s, folders: [...s.folders, f] }));
    setShowCreate(false);
  };
  const deleteFolder = (id: string) => {
    update(s => ({
      ...s,
      folders: s.folders.filter(f => f.id !== id),
      memos: s.memos.map(m => m.folderId === id ? { ...m, folderId: null } : m),
      activeFolder: s.activeFolder === id ? "all" : s.activeFolder,
    }));
    setDeleteTarget(null);
  };
  const renameFolder = (id: string, name: string) =>
    update(s => ({ ...s, folders: s.folders.map(f => f.id === id ? { ...f, name } : f) }));
  const setActiveFolder = (id: string) =>
    update(s => ({ ...s, activeFolder: id }));

  // ── Grouping ───────────────────────────────────────────────
  const visibleMemos = state.activeFolder === "all"
    ? state.memos
    : state.memos.filter(m => m.folderId === state.activeFolder);

  const grouped: Record<string, Record<string, Memo[]>> = {};
  visibleMemos.forEach(m => {
    const mk = monthKey(m.date);
    if (!grouped[mk]) grouped[mk] = {};
    if (!grouped[mk][m.date]) grouped[mk][m.date] = [];
    grouped[mk][m.date].push(m);
  });
  const months = Object.keys(grouped).sort().reverse();
  const handleClickEmpty = (d: string) => { setDateVal(d); inputRef.current?.focus(); };

  const today = new Date();
  const todayLabel = `${today.getFullYear()}.${String(today.getMonth() + 1).padStart(2, "0")}.${String(today.getDate()).padStart(2, "0")}`;
  const noteMemo = noteMemoId ? state.memos.find(m => m.id === noteMemoId) ?? null : null;

  if (!hydrated) return null;

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>

      {/* ── TOPBAR ────────────────────────────────────────────── */}
      <div className="psv-topbar" style={{
        height: 64, minHeight: 64,
        display: "flex", alignItems: "center", padding: "0 24px",
        borderBottom: "1px solid rgba(255,255,255,0.09)",
        background: "rgba(13,13,16,0.97)", zIndex: 100,
        boxShadow: "0 1px 0 rgba(255,255,255,0.04)",
      }}>
        <div className="psv-brand" style={{ display: "flex", flexDirection: "column", gap: 3 }}>
          <div className="psv-titleText" style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 15, fontWeight: 700, color: "rgba(255,255,255,0.92)", letterSpacing: "0.02em", lineHeight: 1.2 }}>
            One PSV
          </div>
          <div className="psv-subText" style={{ fontFamily: "'Noto Sans KR',sans-serif", fontSize: 12, color: "rgba(255,255,255,0.38)", lineHeight: 1.2, letterSpacing: "0.01em" }}>
            {state.activeFolder === "all"
              ? "한줄 메모장"
              : (state.folders.find(f => f.id === state.activeFolder)?.name ?? "한줄 메모장")}
          </div>
        </div>
        <div style={{ flex: 1 }} />
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: "rgba(255,255,255,0.28)", letterSpacing: "0.04em" }}>{todayLabel}</span>
      </div>

      {/* ── BODY ──────────────────────────────────────────────── */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>

        {/* SIDEBAR */}
        <div style={{ width: "var(--sidebar-w)", minWidth: "var(--sidebar-w)", borderRight: "1px solid var(--border)", display: "flex", flexDirection: "column", padding: "10px 8px", gap: 2, overflowY: "auto" }}>

          <button onClick={() => setActiveFolder("all")}
            style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", borderRadius: 8, border: "none", background: state.activeFolder === "all" ? "rgba(255,255,255,0.09)" : "none", color: state.activeFolder === "all" ? "var(--text)" : "var(--text2)", cursor: "pointer", fontSize: 14, fontWeight: state.activeFolder === "all" ? 600 : 400, fontFamily: "'Noto Sans KR',sans-serif", textAlign: "left", width: "100%", transition: "background 0.15s" }}
            onMouseEnter={e => { if (state.activeFolder !== "all") e.currentTarget.style.background = "rgba(255,255,255,0.05)"; }}
            onMouseLeave={e => { if (state.activeFolder !== "all") e.currentTarget.style.background = "none"; }}>
            <span style={{ fontSize: 16, color: state.activeFolder === "all" ? "rgba(255,255,255,0.35)" : "rgba(255,255,255,0.16)", lineHeight: 1, flexShrink: 0 }}>·</span>
            All
          </button>

          {state.folders.map(f => (
            <FolderItem key={f.id} folder={f} isActive={state.activeFolder === f.id}
              memoCount={state.memos.filter(m => m.folderId === f.id).length}
              onSelect={() => setActiveFolder(f.id)}
              onDelete={() => setDeleteTarget(f)}
              onRename={name => renameFolder(f.id, name)} />
          ))}

          <button onClick={() => setShowCreate(true)}
            style={{ display: "flex", alignItems: "center", gap: 6, padding: "7px 10px", marginTop: 6, borderRadius: 8, border: "1px dashed rgba(255,255,255,0.13)", background: "none", color: "var(--text3)", cursor: "pointer", fontSize: 13, fontFamily: "'Noto Sans KR',sans-serif", width: "100%", transition: "all 0.15s" }}
            onMouseEnter={e => { e.currentTarget.style.color = "var(--text2)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.25)"; }}
            onMouseLeave={e => { e.currentTarget.style.color = "var(--text3)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.13)"; }}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
              <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
            </svg>
            폴더 만들기
          </button>
        </div>

        {/* MAIN + NOTE */}
        <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

          <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            {/* INPUT BAR */}
            <div style={{ height: "var(--input-h)", minHeight: "var(--input-h)", display: "flex", alignItems: "center", padding: "0 16px", gap: 10, borderBottom: "1px solid var(--border)", background: "var(--surface)" }}>
              <input type="date" value={dateVal} onChange={e => setDateVal(e.target.value)}
                style={{ background: "var(--surface2)", border: "1px solid var(--border2)", borderRadius: 8, color: "var(--text)", fontFamily: "'JetBrains Mono',monospace", fontSize: 12, padding: "6px 10px", outline: "none", cursor: "pointer", flexShrink: 0, colorScheme: "dark" }} />
              <input ref={inputRef} type="text" value={inputText}
                onChange={e => setInputText(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") addMemo(); }}
                placeholder="메모를 입력하고 Enter…" maxLength={200}
                style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "var(--text)", fontFamily: "'Noto Sans KR',sans-serif", fontSize: 14, padding: "0 4px" }} />
              <button onClick={addMemo}
                style={{ background: "var(--accent)", border: "none", borderRadius: 7, color: "#111", fontSize: 12, fontWeight: 600, padding: "6px 14px", cursor: "pointer", flexShrink: 0, fontFamily: "'Noto Sans KR',sans-serif", transition: "opacity 0.15s" }}
                onMouseEnter={e => (e.currentTarget.style.opacity = "0.82")}
                onMouseLeave={e => (e.currentTarget.style.opacity = "1")}>추가</button>
            </div>

            {/* PANELS */}
            <div
              style={{ flex: 1, overflowY: "auto", padding: "20px 20px 40px", display: "flex", flexDirection: "column", gap: 28 }}
              onClick={() => { if (openMenuId) setOpenMenuId(null); }}
              onDragOver={e => e.preventDefault()}
            >
              {months.length === 0 && (
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10, paddingTop: 80, color: "var(--text3)", fontSize: 13 }}>
                  <div style={{ fontSize: 28 }}>✦</div>
                  <div>메모를 입력해 시작하세요</div>
                </div>
              )}
              {months.map(mk => (
                <MonthPanel
                  key={mk} mk={mk} byDay={grouped[mk]} openMenuId={openMenuId}
                  draggingId={draggingId} dropTarget={dropTarget}
                  onUpdate={updateMemo}
                  onOpenMenu={id => setOpenMenuId(id)}
                  onCloseMenu={() => setOpenMenuId(null)}
                  onPickColor={pickColor}
                  onPickImage={async (id, dataUrl) => { await pickImage(id, dataUrl); setOpenMenuId(null); }}
                  onClearImage={id => { clearImage(id); setOpenMenuId(null); }}
                  onOpenNote={id => setNoteMemoId(noteMemoId === id ? null : id)}
                  onDelete={deleteMemo}
                  onClickEmpty={handleClickEmpty}
                  onDragStart={handleDragStart}
                  onDragEnd={handleDragEnd}
                  onDragOverSlot={handleDragOverSlot}
                  onDropSlot={handleDropSlot}
                />
              ))}
            </div>
          </div>

          {/* NOTE PANEL */}
          <div style={{ width: noteMemo ? "46%" : 0, minWidth: 0, overflow: "hidden", flexShrink: 0, transition: "width 0.25s cubic-bezier(0.4,0,0.2,1)", borderLeft: noteMemo ? "1px solid rgba(255,255,255,0.07)" : "none" }}>
            {noteMemo && <NotePanel memo={noteMemo} onSave={saveNote} onClose={() => setNoteMemoId(null)} />}
          </div>
        </div>
      </div>

      {showCreate && <FolderModal onConfirm={createFolder} onCancel={() => setShowCreate(false)} />}
      {deleteTarget && (
        <DeleteFolderModal name={deleteTarget.name}
          onConfirm={() => deleteFolder(deleteTarget.id)}
          onCancel={() => setDeleteTarget(null)} />
      )}
    </div>
  );
}
