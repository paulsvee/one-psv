import { NextRequest, NextResponse } from "next/server";
import { getAllFolders, createFolder } from "@/lib/db";
import { randomUUID } from "crypto";

export async function GET() {
  try {
    const folders = getAllFolders();
    return NextResponse.json({ folders });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name } = await req.json();
    if (!name?.trim()) return NextResponse.json({ error: "name required" }, { status: 400 });
    const id = randomUUID();
    createFolder(id, name.trim());
    return NextResponse.json({ id, name: name.trim() });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
