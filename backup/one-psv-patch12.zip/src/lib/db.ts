import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const DB_DIR = path.join(process.cwd(), "data");
const DB_PATH = path.join(DB_DIR, "one-psv.db");

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (_db) return _db;
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

  _db = new Database(DB_PATH);
  _db.pragma("journal_mode = WAL");
  _db.pragma("foreign_keys = ON");

  _db.exec(`
    CREATE TABLE IF NOT EXISTS folders (
      id         TEXT PRIMARY KEY,
      name       TEXT NOT NULL,
      created_at INTEGER NOT NULL DEFAULT (unixepoch('now') * 1000)
    );

    CREATE TABLE IF NOT EXISTS memos (
      id         TEXT PRIMARY KEY,
      folder_id  TEXT REFERENCES folders(id) ON DELETE SET NULL,
      date       TEXT NOT NULL,
      text       TEXT NOT NULL,
      created_at INTEGER NOT NULL DEFAULT (unixepoch('now') * 1000)
    );

    CREATE INDEX IF NOT EXISTS idx_memos_date      ON memos(date);
    CREATE INDEX IF NOT EXISTS idx_memos_folder_id ON memos(folder_id);
  `);

  return _db;
}

export type FolderRow = {
  id: string;
  name: string;
  created_at: number;
  memo_count: number;
};

export type MemoRow = {
  id: string;
  folder_id: string | null;
  date: string;
  text: string;
  created_at: number;
};

export function getAllFolders(): FolderRow[] {
  return getDb()
    .prepare(`
      SELECT f.id, f.name, f.created_at,
             COUNT(m.id) AS memo_count
        FROM folders f
        LEFT JOIN memos m ON m.folder_id = f.id
       GROUP BY f.id
       ORDER BY f.created_at ASC
    `)
    .all() as FolderRow[];
}

export function createFolder(id: string, name: string) {
  getDb().prepare(`INSERT INTO folders (id, name) VALUES (?, ?)`).run(id, name);
}

export function renameFolder(id: string, name: string) {
  getDb().prepare(`UPDATE folders SET name = ? WHERE id = ?`).run(name, id);
}

export function deleteFolder(id: string) {
  getDb().prepare(`DELETE FROM folders WHERE id = ?`).run(id);
}

export function getMemos(folderId?: string): MemoRow[] {
  if (folderId) {
    return getDb()
      .prepare(`SELECT * FROM memos WHERE folder_id = ? ORDER BY date DESC, created_at ASC`)
      .all(folderId) as MemoRow[];
  }
  return getDb()
    .prepare(`SELECT * FROM memos ORDER BY date DESC, created_at ASC`)
    .all() as MemoRow[];
}

export function createMemo(id: string, folderId: string | null, date: string, text: string) {
  getDb()
    .prepare(`INSERT INTO memos (id, folder_id, date, text) VALUES (?, ?, ?, ?)`)
    .run(id, folderId ?? null, date, text);
}

export function updateMemoText(id: string, text: string) {
  getDb().prepare(`UPDATE memos SET text = ? WHERE id = ?`).run(text, id);
}

export function deleteMemo(id: string) {
  getDb().prepare(`DELETE FROM memos WHERE id = ?`).run(id);
}
