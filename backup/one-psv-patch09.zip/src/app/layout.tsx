import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "한줄 메모장 · One-psv",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
